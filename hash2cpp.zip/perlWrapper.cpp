#include "perlWrapper.h"
#include <string>
#include <utility>

perlWrapper::perlWrapper(){
	PERL_SYS_INIT3(NULL,NULL,NULL);
	my_perl = perl_alloc();
	perl_construct(my_perl);
	PL_exit_flags |= PERL_EXIT_DESTRUCT_END;
}

perlWrapper::~perlWrapper(){
	perl_destruct(my_perl);
	perl_free(my_perl);
	PERL_SYS_TERM();
}

void perlWrapper::runInterpreterWithPerlFile(char *filename){
	my_argv[0] = "";
	my_argv[1] = filename;
	perl_parse(my_perl,0,2,my_argv,(char**)NULL);
	perl_run(my_perl);
}

hashS* perlWrapper::getHashInfo(string perlFunc){
	dSP;				//inicializa o ponteiro da pilha
	ENTER;
	SAVETMPS;		//variavel temporaria
	PUSHMARK(SP);	//lembra ponteiro na pilha
	PUTBACK;
	int numEl = call_pv(perlFunc.c_str(),G_ARRAY);
	SPAGAIN;

	cout << numEl << endl;
	hashS* hash = new hashS;
	string sep = "£";

	string key; vector<string> values;
	for (int i=0; i<numEl; i++){
		if (i==0) key = POPp;
		else{
			string aux;
			if (aux != sep){
				values.push_back(aux);
				cout << "___" << key << endl;
				cout << "___" << aux << endl;
			}
			else{
				pair<string, vector<string> > par(key,values);
				(*hash).push_back(par);
				key = POPp;
				++i;
			}
		}
	}

	PUTBACK;
	FREETMPS;
	LEAVE;

	return hash;
}
