#! /usr/bin/perl

use lib './';
use modulePerl;

sub returnHash{
	#my $separator = shift;	#receive separator char
	my $separator = "£";
	my %hash = ("chave1" => ["a", "b", "c"],
					"chave2" => ["ǫ", "ķ", "ż"],
					"chave3" => ["ţ", "ş", "ĸ"]);
	my @res = ("NULL");
	foreach my $key (keys %hash){
		push(@res, $key);
		foreach my $val (@{%hash{$key}}){
			push(@res, $val);
		}
		push(@res, $separator);
	}
	shift(@res);	#remove NULL element used
						#initialize array
	pop(@res);	#remove extra separator

	return reverse(@res);
	#return \@res;
}

#my $s = "£";
#my $resP = returnHash();
#my @res = @{$resP}; undef $resP;
#print "Received array: ", @res, "\n";
#my %receivedHash = ("NULL" => ["NULL"]);
#my $index = 0; my $skip = 0;
#my $key = shift(@res);
#foreach my $val (@res){
	#my $inserted = 0;
	#if ($skip){
		#$key = $val;
		#$skip = 0;
	#}
	#else{
		#if ($val eq $s){
			#$index++;
			#$inserted = 1;
			#$skip = 1;
		#}
		#if ($inserted != 1){
			#my $found = 0;
			#foreach my $keyV (keys %receivedHash){
				#if ($keyV eq $key){
					#push (@{$receivedHash{$key}}, $val);
					#$found = 1;
				#}
			#}
			#if ($found != 1){
				#%receivedHash = (%receivedHash, $key => [$val]);
			#}
		#}
	#}
#}
#
#delete $receivedHash{"NULL"};
#foreach my $key (keys %receivedHash){
	#print "\n$key:";
	#foreach my $val (@{%receivedHash{$key}}){
		#print "\t$val";
	#}
#}
#print "\n";
