//#include <EXTERN.H>
#include "/usr/lib/x86_64-linux-gnu/perl/5.24.1/CORE/EXTERN.h"
#include <perl.h>
#include <string>
#include <iostream>
#include <vector>
#include <utility>			//talvex trocar para outra lib (pair)

using namespace std;

typedef vector<pair<string,vector<string> > > hashS;

class perlWrapper{
	public:
		perlWrapper();
		~perlWrapper();
		hashS* getHashInfo(string);
		void runInterpreterWithPerlFile(char*);
	private:
		PerlInterpreter *my_perl;
		char *my_argv[2];
};
