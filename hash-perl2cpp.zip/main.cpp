#include <iostream>
#include <string>
#include "perlWrapper.h"

using namespace std;

int
main(void){
	perlWrapper perlwrapper;
	perlwrapper.runInterpreterWithPerlFile("sendHash.pl");

	hashS *hash = perlwrapper.getHashInfo("returnHash");

	for (unsigned i=0; i<(*hash).size(); i++){
		cout << "Key: " << (*hash)[i].first << endl;
		cout << "Values: " << endl;
		for (unsigned j=0; j<(*hash)[i].second.size(); j++)
			cout << "(#" << j << "): " << (*hash)[i].second[j] << endl;
	}

	return 0;
}
