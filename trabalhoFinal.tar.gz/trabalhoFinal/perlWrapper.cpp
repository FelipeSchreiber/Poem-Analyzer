#include "perlWrapper.h"

perlWrapper::perlWrapper(){
	PERL_SYS_INIT3(NULL,NULL,NULL);
	my_perl = perl_alloc();
	perl_construct(my_perl);
	PL_exit_flags |= PERL_EXIT_DESTRUCT_END;
}

perlWrapper::~perlWrapper(){
	perl_destruct(my_perl);
	perl_free(my_perl);
	PERL_SYS_TERM();
}

void perlWrapper::runInterpreterWithPerlFile(char *filename){
	my_argv[0] = "";
	my_argv[1] = filename;
	perl_parse(my_perl,0,2,my_argv,(char**)NULL);
	perl_run(my_perl);
}

int perlWrapper::getSonetAnalysis(int fd, int mode){
	dSP;				//inicializa o ponteiro da pilha
	ENTER;
	SAVETMPS;		//variavel temporaria
	PUSHMARK(SP);	//lembra ponteiro na pilha
	XPUSHs(sv_2mortal(newSViv(fd)));
	XPUSHs(sv_2mortal(newSViv(mode)));
	PUTBACK;
	//string func("isSonnet");
	string func("interfaceIsSonet");
	call_pv(func.c_str(),G_SCALAR);
	SPAGAIN;

	int res = POPi;
	PUTBACK;
	FREETMPS;
	LEAVE;

	return res;
}

int perlWrapper::getFileStats(int fd,vector<int>*save){
	dSP;				//inicializa o ponteiro da pilha
	ENTER;
	SAVETMPS;		//variavel temporaria
	PUSHMARK(SP);	//lembra ponteiro na pilha
	XPUSHs(sv_2mortal(newSViv(fd)));
	PUTBACK;
	//string func("fileStats");
	string func("interfaceFileStats");
	call_pv(func.c_str(),G_ARRAY);
	SPAGAIN;

	for(int j = 0; j<3; j++)
		save->push_back(POPi);

	PUTBACK;
	FREETMPS;
	LEAVE;
	return 0;
}

int perlWrapper::getRepetitions(int fd,Heap<myClass>*palavras){
	dSP;				//inicializa o ponteiro da pilha
	ENTER;
	SAVETMPS;		//variavel temporaria
	PUSHMARK(SP);	//lembra ponteiro na pilha
	XPUSHs(sv_2mortal(newSViv(fd)));
	PUTBACK;
	string func("interfaceCountRep");
	int vectorLength = call_pv(func.c_str(),G_ARRAY);
	SPAGAIN;
  for(int j = 0; j<vectorLength/2; j++){
		STRLEN len;
		const char *s = SvPVx(POPs, len);
		string temp(s);
		myClass *palavra = new myClass(temp,POPi);
		palavras->insert(palavra);
	}
	PUTBACK;
	FREETMPS;
	LEAVE;
	return 0;
}

int perlWrapper::getRima(hashS &retorno, string &padrao, vector<string> &palavras,int mode){
	dSP;				//inicializa o ponteiro da pilha
	ENTER;
	SAVETMPS;		//variavel temporaria
	PUSHMARK(SP);	//lembra ponteiro na pilha
	for(unsigned int i = 0;i<palavras.size();i++)
		XPUSHs(sv_2mortal(newSVpv(palavras[i].c_str(),palavras[i].length())));
	XPUSHs(sv_2mortal(newSViv(mode)));
	PUTBACK;

	string func("interfaceDetRima");
	int numEl = call_pv(func.c_str(),G_ARRAY);
	SPAGAIN;

	string sep = "£";

	string key; vector<string> values;
	for (int i=0; i<numEl-1; i++){
		if (i==0) key = POPp;
		else{
			string aux = POPp;
			if (aux != sep)
				values.push_back(aux);
			else{
				pair<string, vector<string> > par(key,values);
				retorno.push_back(par);
				key = POPp;
				while(values.size())
					values.pop_back();
				++i;
			}
		}
	}
	pair<string, vector<string> > par(key,values);
	retorno.push_back(par);
	padrao = POPp;

	PUTBACK;
	FREETMPS;
	LEAVE;

	return 0;
}
