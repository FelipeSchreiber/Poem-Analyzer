#ifndef PERL_WRAPPER
#define PERL_WRAPPER
#include "/usr/lib/x86_64-linux-gnu/perl/5.24.1/CORE/EXTERN.h"
/*#include "/usr/lib/x86_64-linux-gnu/perl/5.22.1/CORE/EXTERN.h"*/
#include <perl.h>
#include <string>
#include "heap.h"
#include <vector>
#include <iostream>

using namespace std;

typedef vector<pair<string,vector<string> > > hashS;
//utilizado por detRima

class perlWrapper{
	public:
		perlWrapper();
		~perlWrapper();
		void runInterpreterWithPerlFile(char*);
		int getFileStats(int fd,vector<int>*);
		int getSonetAnalysis(int,int);
		int getRepetitions(int fd,Heap<myClass>*);
		int getRima(hashS&,string&, vector<string>&,int);
	private:
		PerlInterpreter *my_perl;
		char *my_argv[2];
};

#endif
