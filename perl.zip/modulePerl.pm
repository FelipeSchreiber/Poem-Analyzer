#! /usr/bin/perl

package modulePerl;

use 5.010000;
use strict;
use warnings;
use Carp;
use lib './';
require Exporter;

our @ISA = qw(Exporter);
our %EXPORT_TAGS=('all' => [ qw() ]);
our @EXPORT_OK=(@{ $EXPORT_TAGS{'all'} });

our $EXPORT = qw(
printArgs
);
our $VERSION = '0.01';

sub oi{
	print shift;
}

sub printArgs{
	my $i = 0;
	foreach (@_){
		print "Arg[", $i, "]: ", $_, "\n"; $i++;
	}
}
