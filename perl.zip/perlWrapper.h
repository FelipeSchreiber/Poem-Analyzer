//#include <EXTERN.H>
#include "/usr/lib/x86_64-linux-gnu/perl/5.24.1/CORE/EXTERN.h"
#include <perl.h>
#include <string>
#include <iostream>

using namespace std;

class perlWrapper{
	public:
		perlWrapper();
		~perlWrapper();
		void runInterpreterWithPerlFile(char *filename);
		int getMathResult(int a,int b, string perlFunc);
		int getInputFileInfo(string inputFile, string perlFunc);
	private:
		PerlInterpreter *my_perl;
		char *my_argv[2];
};
