#! /usr/bin/perl

use lib './';
use modulePerl;

sub lineCounter{
	#printArgs (@_);

	my ($c) = @_;
	my $lines = 0;

	$inputFile = $c . ".txt";

	print "Opening, ", $inputFile, "\n";
	open (my $in, "<$inputFile") or die "Can't open $inputFile: $!";

	while (<$in>){
		$lines++;
		print "line #", $lines, ":", $_, "\n";
	}

	close $in or die "Can't close $inputFile: $!";
	return $lines;
}

sub wordCounter{
	#printArgs (@_);

	my ($c) = @_;
	my $totWords = 0;

	$inputFile = $c . ".txt";

	print "Opening, ", $inputFile, "\n";
	open (my $in, "<$inputFile") or die "Can't open $inputFile: $!";

	while (<$in>){
		my @line = split(' ', $_);
		my $words = 0;
		foreach (@line){ $words++; };
		print "Line has ", $words, " words\n";
		$totWords += $words;
	}

	close $in or die "Can't close $inputFile: $!";
	return $totWords;
}
