#! /usr/bin/perl

use lib './';
use modulePerl;

sub expo{
	my ($a,$b) = @_;
	return $a**$b;
}

sub sum{
	my ($a,$b) = @_;
	return $a+$b;
}

sub mul{
	my ($a,$b) = @_;
	return $a*$b;
}
