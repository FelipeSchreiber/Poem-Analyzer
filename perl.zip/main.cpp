#include <iostream>
#include <string>
#include "perlWrapper.h"

using namespace std;

int
main(void){
	perlWrapper perlwrapper;
	perlwrapper.runInterpreterWithPerlFile("calc.pl");
	srand(time(0));

	cout << "Resultado " << perlwrapper.getMathResult(rand()%10,rand()%10,
										"mul") << endl;
	cout << "Resultado " << perlwrapper.getMathResult(rand()%100,2,"expo") << endl;

	perlwrapper.runInterpreterWithPerlFile("string.pl");
	cout << "Line count result: " << perlwrapper.getInputFileInfo("test",
												"lineCounter") << endl;
	cout << "Word count result: " << perlwrapper.getInputFileInfo("test",
												"wordCounter");
	cout << endl;
	return 0;
}
