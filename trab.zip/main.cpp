#include <iostream>
#include <string>
#include "heap.h"
#include <vector>
#include "runPerl.h"
#include "perlWrapper.h"

using namespace std;

int main(){
	bool quit = false;
	perlWrapper perlwrapper;
	int choice = 7;
	while(!quit){
		choice = ShowMenu();
		switch (choice) {
			case 1:{
					string path;
					printf("\e[1;1H\e[2J");
					cout<<"\nDigite o caminho até o diretorio desejado: \n"<<endl;
					getline(cin,path);
					ls(path);
					break;
				}
			case 2:
				printf("\e[1;1H\e[2J");
				if( runIsSonet(perlwrapper) )
					cout<<"\nÉ soneto\n"<<endl;
				else
					cout<<"\nNao é soneto\n"<<endl;
				break;
			case 3:{
					printf("\e[1;1H\e[2J");
					vector<int> fileStats;
					if( runStats(perlwrapper,&fileStats,-1) ){
						cout<<"\nTotal de palavras: " << fileStats[2] << endl;
						cout << "Total de versos: " << fileStats[1] << endl;
						cout << "Total de estrofes: " << fileStats[0] << endl;
					}
					break;
				}
			case 4:{
					printf("\e[1;1H\e[2J");
					hashS *retorno = (hashS *) NULL;
					string padrao;
					runDetRima(perlwrapper,retorno,padrao);
					cout<<"\nPadrao de rimas encontrado: "<<
						padrao<<endl;
					cout<<"\nRimas encontradas: "<<endl;
					for (unsigned i=0; i<(*retorno).size(); i++){
						cout << "(#" << i+1 << "):"<< endl;
						cout << (*retorno)[i].first << endl;
						for (unsigned j=0; j<(*retorno)[i].second.size(); j++)
							cout << (*retorno)[i].second[j] << endl;
					}
					cout<<endl;

					break;
				}
			case 5:{
					printf("\e[1;1H\e[2J");
					Heap<myClass> palavras;
					if(runRepetitions(perlwrapper, palavras))
						while(!palavras.is_empty()){
							myClass *ptr = palavras.pop();
							cout<<ptr->vertexId<<": "<<ptr->value<<endl;
						}
				}
			break;
			case 6:
				printf("\e[1;1H\e[2J");
				cout<<"Saindo..."<<endl;
				quit = true;
				break;
				default:
					printf("\e[1;1H\e[2J");
					cout << "Bad Input, Try again " << endl;
		}
	}
	return 0;
}
