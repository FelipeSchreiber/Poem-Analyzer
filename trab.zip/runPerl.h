#ifndef RUN_PERL
#define RUN_PERL
#include <fcntl.h>
#include <string>
#include "heap.h"
#include "perlWrapper.h"
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>
#include <dirent.h>

int ShowMenu();
int ls(string);
int detRimasMenu();
int runStats(perlWrapper&,vector<int>*, int);
int runIsSonet(perlWrapper&);
int runRepetitions(perlWrapper &,Heap<myClass>&);
void runDetRima(perlWrapper&,hashS*,string&);
vector<string> getLastWords(Heap<int>*,string,int);
void getEstrofes(Heap<int> &);
bool isTXT(string);
#endif
